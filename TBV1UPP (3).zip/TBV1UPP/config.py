# === Bot Core Config ===
BOT_TOKEN = '7978821331:AAEccI_zR3UmigHP4YVI2L3PF7WEX5NBSeY'
ADMIN_ID = 7800450911

# === WooCommerce API Credentials ===
WC_CONSUMER_KEY = 'ck_9754ff35606c3c4e047a12c8d8ed78d9b89365b5'
WC_CONSUMER_SECRET = 'cs_5c7d68f43daa2963fbe2e520b1d42e7a98933b0a'
WC_API_URL = 'https://thegreenteam.store/wp-json/wc/v3'

# === File Storage Paths ===
TRACKING_FILE = 'tracking_data.json'
USER_DB_FILE = 'users.json'
ROYAL_MAIL_TRACKING_URL = 'https://www.royalmail.com/track-your-item'

# === Payment & Invoice Settings ===
OUTPUT_FOLDER = 'invoices'
LOGO_PATH = 'assets/logo.png'


