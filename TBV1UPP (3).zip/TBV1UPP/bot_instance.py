# bot_instance.py

from telebot import TeleBot
from config import BOT_TOKEN

bot = TeleBot(BOT_TOKEN)
